import file_handel
r = file_handel.read(1)
print(r)